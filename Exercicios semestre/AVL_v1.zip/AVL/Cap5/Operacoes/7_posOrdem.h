#ifndef POSORDEM_ARVORE_BINARIA_H
#define POSORDEM_ARVORE_BINARIA_H

/* --------------------------*/
void posOrdem(pNohArvore raiz, FuncaoImpressao fi){

}

#endif





