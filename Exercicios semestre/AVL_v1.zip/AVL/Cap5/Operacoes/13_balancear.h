#ifndef BALANCEAR_ARVORE_H
#define BALANCEAR_ARVORE_H

#include <math.h>


pNohArvore balancearRecursivo(pNohArvore raiz) {

}


void balancear(pDArvore arvore) {

   // a l�gica necess�ria para realizar o balanceamento da �rvore est� implementada
   // com o c�digo da opera��o incluirInfo, pois usa a pilha de recurs�o para verificar
   // se algum n�h do caminho onde foi feita a inclus�o ficou desbalanceado (FB = 2 ou -2 )
}

#endif
