#ifndef QTDEFOLHAS_ARVORE_BINARIA_H
#define QTDEFOLHAS_ARVORE_BINARIA_H

/* -------------------------------------------*/
int quantidadeFolhasRecursiva(pNohArvore raiz){

}


int quantidadeFolhas(pDArvore arvore){

}
#endif







