#ifndef QTDENOHS_ARVORE_BINARIA_H
#define QTDENOHS_ARVORE_BINARIA_H

/* -------------------------------------------*/
int quantidadeNohsRecursiva(pNohArvore raiz){

}


int quantidadeNohs(pDArvore arvore){

}
#endif







