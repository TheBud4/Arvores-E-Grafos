#ifndef UNIR_LISTA_H
#define UNIR_LISTA_H

pDLista unirListas(pDLista lista1, pDLista lista2, FuncaoComparacao fc )
{
    pDLista pNovaLista = criarLista();


    return pNovaLista;
}

#endif
