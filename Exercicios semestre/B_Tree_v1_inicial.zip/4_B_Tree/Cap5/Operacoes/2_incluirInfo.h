#ifndef INCLUIR_INFO_BTREE_H
#define INCLUIR_INFO_BTREE_H

//pNohBTree buscarInfoBTreeRecursivo(pNohBTree , void *, FuncaoComparacao);

//---------------------------------
int comparaChaveValor(void *info1, void *info2){
    pChaveValor  p1 = (pChaveValor) info1;
    pChaveValor  p2 = (pChaveValor) info2;
    return *((int*)(p2->chave)) - *((int*)(p1->chave));
}

//---------------------------------
pNohBTree criaNoh(){

    pNohBTree pNovo           = malloc(sizeof(NohBTree));
    pNovo->listaChavesValores = criarLista();
    pNovo->primeiroFilho      = NULL;
    pNovo->pai                = NULL;
    return pNovo;
}

//---------------------------------
ChaveValor* criaChaveValor(void* chave, void* valor, pNohBTree filhoMaior){

    ChaveValor* pcv = malloc(sizeof(struct chaveValor));
    pcv->chave      = chave;
    pcv->valor      = valor;
    pcv->filhoMaior = filhoMaior;
    return pcv;
}

/* --------------------------*/
int ehFolha(pNohBTree raiz){

   if(raiz == NULL)
      return 0;

   if(raiz->primeiroFilho != NULL)
      return 0;

   int i=1;
   while (i <= raiz->listaChavesValores->quantidade){

        pChaveValor pcv = buscarInfoPos(raiz->listaChavesValores, i);

        if(pcv->filhoMaior != NULL){
           return 0;
        }

        i++;
    }
    // eh folha, retorna 1 [true]
    return 1;
}

/* --------------------------*/
pNohBTree incluirInfoBTreeRecursivo(pNohBTree raiz, int ordem, void* chave, void* valor, FuncaoComparacao pfc){

   return NULL;
}

/* ----------------------------------------------------------*/
int incluirInfoBTree(pDBTree arvore, void *chave, void *valor, FuncaoComparacao pfc){

     desenhaArvore(arvore, imprimeInt);
     printf("\n ---> Incluindo ....: %d [ ", *((int*)chave));

     pNohBTree novaRaiz = incluirInfoBTreeRecursivo(arvore->raiz, arvore->ordem, chave, valor, pfc);
     if (novaRaiz == NULL){
        printf(" -->> Erro! Chave informada j� existe na �rvore!!! <<--");
     }
     else{
        arvore->raiz = novaRaiz;
     }

     printf(" ] \n\n");
     return 1;
}

#endif

