#ifndef STRUCT_DESCRITOR_BTREE_H
#define STRUCT_DESCRITOR_BTREE_H

struct dBTree{
    pNohBTree  raiz;
    int        ordem;
};


#endif
