# grafosC
Modelo de códigos de grafo em C. Usado para final didático de elucidação da matéria.    

Lista de códigos:

grafo de lista de adjência - Código do cabeçalho = grafo-lista-adj.c 

grafo de lista de adjência - Código da implementação = grafo-lista-adj-implementacao.c

grafo de lista de adjência - Código da implementação com impressão na tela  = grafo-lista-adj-completo.c

grafo busca em profundidade - Código de implementação da busca = grafo-busca-profundidade.c

Para entender mais sobre grafo com as imagens que fazem parte da explicação pode acessar o seguinte link:
https://medium.com/@paulomartins_10299/grafos-c%C3%B3digo-das-opera%C3%A7%C3%B5es-b%C3%A1sicas-e91d9a79e828

