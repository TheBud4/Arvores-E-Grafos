#ifndef STRUCTS_PILHA_H
#define STRUCTS_PILHA_H

/* ------------------------------- */
struct dPilha{
    /* o topo eh no final da lista */
    pDLista pdLista;
};

#endif
