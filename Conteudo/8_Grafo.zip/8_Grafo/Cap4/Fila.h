#ifndef FILA_H
#define FILA_H

#include "TAD_Fila.h"

#include "../Cap3/Lista.h"

#include "OperacoesFila/0_structs.h"

#include "OperacoesFila/1_criarFila.h"

#include "OperacoesFila/2_enfileirarInfo.h"

#include "OperacoesFila/3_desenfileirarInfo.h"

#include "OperacoesFila/4_filaVazia.h"

#endif // FILA_H
