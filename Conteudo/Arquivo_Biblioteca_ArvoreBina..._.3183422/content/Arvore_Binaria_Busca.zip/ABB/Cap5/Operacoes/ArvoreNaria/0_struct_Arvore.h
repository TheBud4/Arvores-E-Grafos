#ifndef STRUCT_ARVORE_H
#define STRUCT_ARVORE_H

struct nohArvore{
   void*      info;
   pDLista    filhos;
};

#endif
