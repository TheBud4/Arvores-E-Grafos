#ifndef EXCLUIRINFO_BTREE_H
#define EXCLUIRINFO_BTREE_H

int    excluirInfoTRIE  (pDTRIE arvore, void* chave, FuncaoComparacao fc){


    return 0;
}

#endif
