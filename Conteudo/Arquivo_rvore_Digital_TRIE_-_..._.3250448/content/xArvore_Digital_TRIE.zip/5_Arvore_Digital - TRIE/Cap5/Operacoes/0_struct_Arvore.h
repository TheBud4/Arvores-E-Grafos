#ifndef STRUCT_NOH_TRIE_H
#define STRUCT_NOH_TRIE_H

struct nohTRIE{
   int      terminal;   // indica se o n�h representa uma chave ou n�o
   pDLista  filhos;    // ter� a quantidade de filhos de acordo com a ordem - m
};

#endif
