#ifndef STRUCT_DESCRITOR_TRIE_H
#define STRUCT_DESCRITOR_TRIE_H

struct dTRIE{
    struct nohTRIE* raiz;
    pDLista         alfabeto;
    int             ordem;  // m
};


#endif
