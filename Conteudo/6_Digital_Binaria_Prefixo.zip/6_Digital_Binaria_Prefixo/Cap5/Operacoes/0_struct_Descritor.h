#ifndef STRUCT_DESCRITOR_ARVORE_H
#define STRUCT_DESCRITOR_ARVORE_H

struct dPrefixo{
    pNohPrefixo raiz;
    int         quantidadeNohs;
};


#endif
